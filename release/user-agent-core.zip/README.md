
# user-agent-core

Fast and lightweight user-agent parser for browser and device detection.

## Installation

```bash
npm install user-agent-core
```

## Usage

```js
const { detectUA } = require("user-agent-core");
console.log(detectUA("Mozilla/5.0 Chrome/123.0"));
```
